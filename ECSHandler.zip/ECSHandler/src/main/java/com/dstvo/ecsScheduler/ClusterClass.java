package com.dstvo.ecsScheduler;

public class ClusterClass {
        private String clusterName;
        private String serviceName;
        private int scale;
        public ClusterClass(String clusterName, String serviceName, int scale) {
            this.clusterName = clusterName;
            this.serviceName = serviceName;
            this.scale = scale;
        }
        @Override
        public String toString() {
            return "Cluster Name: " + clusterName + ", Service Name: " + serviceName + ", Scale: " + scale;
        }
    }
